from util import dealWithFile as dwf


if __name__ == '__main__':
    dwf.create_data()
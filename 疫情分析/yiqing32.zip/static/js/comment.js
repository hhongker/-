function fajax(id, url) {
    var chart = echarts.init(id, 'white', {renderer: 'canvas'});
    return $.ajax({
        type: "GET",
        url: url,
        dataType: 'json',
        success: function (result) {
            chart.setOption(result);
        }
    })
}

function fdataGrid(id, col, path) {
    $(id).datagrid({
        url: path,
        method: "get",
        columns: col,
        fitColumns: true,
        nowrap: true,//数据长度超出列宽时将会自动截取。
    });
}

function fajaxForWC(id, url,name) {
    var chart = echarts.init(id, 'white', {renderer: 'canvas'});
    chart.on('timelinechanged', function (timeLineIndex) {
            // 发送请求
        if(name == "世界总体疫情变化") fajax(document.getElementById('analyse2'), "analyseW/"+timeLineIndex.currentIndex)

        else fajax(document.getElementById('analyse1'), "analyseC/"+timeLineIndex.currentIndex)
    })
    return $.ajax({
        type: "GET",
        url: url,
        dataType: 'json',
        success: function (result) {
            chart.setOption(result);
        }
    })
}
